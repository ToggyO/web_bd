export const { isPROD, isDEV, API_DOMAIN, API_VERSION, APP_PREFIX = '@BD' } = process.env || {};
