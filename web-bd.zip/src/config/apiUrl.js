export const API_URL = {
  TOKEN: '/token',
};
