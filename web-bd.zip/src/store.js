import configureStore from '@services/configureStore';
const store = configureStore();
export { store };
