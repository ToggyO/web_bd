export const GET_REVIEW_BY_ORDER_REQUEST = 'reviews/review/GET_REVIEW_BY_ORDER_REQUEST';
export const GET_REVIEW_BY_ORDER_SUCCESS = 'reviews/review/GET_REVIEW_BY_ORDER_SUCCESS';
export const GET_REVIEW_BY_ORDER_ERROR = 'reviews/review/GET_REVIEW_BY_ORDER_ERROR';

export const POST_REVIEW_REQUEST = 'reviews/review/POST_REVIEW_REQUEST';
export const POST_REVIEW_SUCCESS = 'reviews/review/POST_REVIEW_SUCCESS';
export const POST_REVIEW_ERROR = 'reviews/review/POST_REVIEW_ERROR';
