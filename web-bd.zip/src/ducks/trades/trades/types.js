export const GET_NEW_REQUEST = 'trades/trades/GET_NEW_REQUEST';
export const GET_NEW_SUCCESS = 'trades/trades/GET_NEW_SUCCESS';
export const GET_NEW_ERROR = 'trades/trades/GET_NEW_ERROR';

export const GET_ACTIVE_REQUEST = 'trades/trades/GET_ACTIVE_REQUEST';
export const GET_ACTIVE_SUCCESS = 'trades/trades/GET_ACTIVE_SUCCESS';
export const GET_ACTIVE_ERROR = 'trades/trades/GET_ACTIVE_ERROR';

export const GET_COMPLETED_REQUEST = 'trades/trades/GET_COMPLETED_REQUEST';
export const GET_COMPLETED_SUCCESS = 'trades/trades/GET_COMPLETED_SUCCESS';
export const GET_COMPLETED_ERROR = 'trades/trades/GET_COMPLETED_ERROR';

export const GET_CANCELED_REQUEST = 'trades/trades/GET_CANCELED_REQUEST';
export const GET_CANCELED_SUCCESS = 'trades/trades/GET_CANCELED_SUCCESS';
export const GET_CANCELED_ERROR = 'trades/trades/GET_CANCELED_ERROR';
