export const GET_BY_ID_REQUEST = 'chat/GET_BY_ID_REQUEST';
export const GET_BY_ID_SUCCESS = 'chat/GET_BY_ID_SUCCESS';
export const GET_BY_ID_ERROR = 'chat/GET_BY_ID_ERROR';
