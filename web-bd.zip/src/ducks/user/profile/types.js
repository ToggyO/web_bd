export const GET_PROFILE_REQUEST = 'user/profile/GET_PROFILE_REQUEST';
export const GET_PROFILE_SUCCESS = 'user/profile/GET_PROFILE_SUCCESS';
export const GET_PROFILE_ERROR = 'user/profile/GET_PROFILE_ERROR';
