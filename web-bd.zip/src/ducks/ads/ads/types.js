export const GET_ALL_REQUEST = 'ads/ads/GET_ALL_REQUEST';
export const GET_ALL_SUCCESS = 'ads/ads/GET_ALL_SUCCESS';
export const GET_ALL_ERROR = 'ads/ads/GET_ALL_ERROR';

export const GET_MY_REQUEST = 'ads/ads/GET_MY_REQUEST';
export const GET_MY_SUCCESS = 'ads/ads/GET_MY_SUCCESS';
export const GET_MY_ERROR = 'ads/ads/GET_MY_ERROR';
