export { default as EditPhoneNumberDisplay } from './EditPhoneNumberDisplay';
