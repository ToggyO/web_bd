export { default as ResetPassword } from './ResetPassword';
