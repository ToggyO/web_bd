export { default as ForgotPassword } from './ForgotPassword';
