/* eslint-disable global-require */
module.exports = {
  plugins: [require('autoprefixer')],
};
